export const siteData = {
	name: 'Lemisch Sanierung & Modernisierung',
	tagline: 'Begleitung für Sanierung & Modernisierung',
	claim: 'Ein Ansprechpartner für Ihr ganzes Haus.',
	phoneDisplay: '0171 1849563',
	phoneHref: 'tel:+491711849563',
	areas: [
		'Tuttlingen',
		'Trossingen',
		'Villingen-Schwenningen',
		'Rottweil',
		'Balingen',
	] as const,
	logo: '/logo.svg',
	logoNegativ: '/logo-negativ.svg',
	icon: '/icon.svg',
} as const;

export type Area = (typeof siteData.areas)[number];
