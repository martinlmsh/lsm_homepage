import { defineCollection } from 'astro:content';
import { glob } from 'astro/loaders';
import { z } from 'astro/zod';

const leistungen = defineCollection({
	loader: glob({ pattern: '**/*.md', base: './src/content/leistungen' }),
	schema: z.object({
		title: z.string(),
		metaTitle: z.string().max(60),
		metaDescription: z.string().max(155),
		h1: z.string(),
		kurzbeschreibung: z.string(),
		reihenfolge: z.number(),
	}),
});

export const collections = { leistungen };
