import { unified } from 'unified';
import remarkParse from 'remark-parse';
import remarkDirective from 'remark-directive';
import remarkRehype from 'remark-rehype';
import rehypeSanitize, { defaultSchema } from 'rehype-sanitize';
import rehypeStringify from 'rehype-stringify';
import { visit } from 'unist-util-visit';

export type ImageMeta = {
	src: string;
	alt?: string;
	breite?: number | null;
	hoehe?: number | null;
};

function remarkInfoCallout() {
	return (tree: unknown) => {
		visit(tree as never, (node: Record<string, unknown>) => {
			if (node.type === 'containerDirective' && node.name === 'info') {
				const data = (node.data as Record<string, unknown>) ?? {};
				node.data = data;
				data.hName = 'aside';
				data.hProperties = {
					className: ['callout-info'],
					role: 'note',
				};
			}
		});
	};
}

function rehypeImageAttrs(images: ImageMeta[]) {
	const bySrc = new Map(images.map((img) => [img.src, img]));

	return (tree: unknown) => {
		visit(tree as never, 'element', (node: {
			tagName?: string;
			properties?: Record<string, unknown>;
		}) => {
			if (node.tagName !== 'img') return;
			let src = String(node.properties?.src ?? '');
			if (src.startsWith('/bilder/') && !src.endsWith('/')) {
				src = `${src}/`;
				node.properties = { ...node.properties, src };
			}
			const meta =
				bySrc.get(src) ??
				bySrc.get(src.replace(/\/$/, '')) ??
				bySrc.get(`${src}/`);
			node.properties = {
				...node.properties,
				loading: 'lazy',
				decoding: 'async',
			};
			if (meta?.breite) node.properties.width = meta.breite;
			if (meta?.hoehe) node.properties.height = meta.hoehe;
			if (meta?.alt && !node.properties.alt) {
				node.properties.alt = meta.alt;
			}
		});
	};
}

const sanitizeSchema = {
	...defaultSchema,
	tagNames: [...(defaultSchema.tagNames ?? []), 'aside'],
	attributes: {
		...defaultSchema.attributes,
		aside: ['className', 'class', 'role'],
		img: [
			...(defaultSchema.attributes?.img ?? []),
			'loading',
			'decoding',
			'width',
			'height',
		],
	},
};

export async function renderMarkdown(
	markdown: string,
	options: { images?: ImageMeta[] } = {},
): Promise<string> {
	const images = options.images ?? [];

	const file = await unified()
		.use(remarkParse)
		.use(remarkDirective)
		.use(remarkInfoCallout)
		.use(remarkRehype)
		.use(() => rehypeImageAttrs(images))
		.use(rehypeSanitize, sanitizeSchema)
		.use(rehypeStringify)
		.process(markdown);

	return String(file);
}
