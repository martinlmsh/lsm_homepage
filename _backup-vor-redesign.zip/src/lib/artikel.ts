import { and, count, desc, eq, sql } from 'drizzle-orm';
import type { Db } from '../db/client';
import { artikel, bilder, type Artikel, type Bild } from '../db/schema';

export const PAGE_SIZE = 10;

export const TYP_LABELS: Record<string, string> = {
	blogartikel: 'Blogartikel',
	projektbericht: 'Projektbericht',
};

export function typLabel(typ: string): string {
	return TYP_LABELS[typ] ?? typ;
}

export async function listPublishedArtikel(
	db: Db,
	opts: { typ?: string; seite?: number } = {},
) {
	const seite = Math.max(1, opts.seite ?? 1);
	const offset = (seite - 1) * PAGE_SIZE;

	const conditions = [eq(artikel.status, 'veroeffentlicht')];
	if (opts.typ) {
		conditions.push(eq(artikel.typ, opts.typ));
	}

	const where = and(...conditions);

	const [totalRow] = await db
		.select({ total: count() })
		.from(artikel)
		.where(where);

	const rows = await db
		.select()
		.from(artikel)
		.where(where)
		.orderBy(desc(artikel.veroeffentlichtAm))
		.limit(PAGE_SIZE)
		.offset(offset);

	const total = totalRow?.total ?? 0;
	const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

	return { rows, total, seite, totalPages };
}

export async function getPublishedArtikelBySlug(
	db: Db,
	slug: string,
): Promise<(Artikel & { titelbild: Bild | null }) | null> {
	const rows = await db
		.select({
			artikel,
			titelbild: bilder,
		})
		.from(artikel)
		.leftJoin(bilder, eq(artikel.titelbildId, bilder.id))
		.where(
			and(eq(artikel.slug, slug), eq(artikel.status, 'veroeffentlicht')),
		)
		.limit(1);

	const row = rows[0];
	if (!row) return null;

	return {
		...row.artikel,
		titelbild: row.titelbild,
	};
}

export async function listPublishedForSitemap(db: Db) {
	return db
		.select({
			slug: artikel.slug,
			veroeffentlichtAm: artikel.veroeffentlichtAm,
			aktualisiertAm: artikel.aktualisiertAm,
		})
		.from(artikel)
		.where(eq(artikel.status, 'veroeffentlicht'))
		.orderBy(desc(artikel.veroeffentlichtAm));
}

export async function listDistinctPublishedTypen(db: Db): Promise<string[]> {
	const rows = await db
		.selectDistinct({ typ: artikel.typ })
		.from(artikel)
		.where(eq(artikel.status, 'veroeffentlicht'))
		.orderBy(sql`${artikel.typ} asc`);

	return rows.map((r) => r.typ);
}

export async function getBilderByR2Keys(db: Db, keys: string[]) {
	if (keys.length === 0) return [];
	const rows = await db.select().from(bilder);
	const keySet = new Set(keys);
	return rows.filter((b) => keySet.has(b.r2Key) || keySet.has(`/bilder/${b.r2Key}`));
}
